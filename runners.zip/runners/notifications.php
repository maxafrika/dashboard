<?php
// notifications.php - Runners app (hardened, logs bodies, avoids sending empty messages)
require_once __DIR__ . '/config.php';

function safe_log($path, $msg) {
    @file_put_contents(__DIR__ . '/' . $path, date('c') . ' - ' . $msg . PHP_EOL, FILE_APPEND);
}

function load_settings() {
    $defaults = [
        'email_enabled' => true,
        'sms_enabled'   => false,
        'email_template' => "Hello {{customer_name}},\n\nYour order {{order_number}} status: {{status}}\n\nTrack: {{order_url}}\n\nThanks,\nRunners",
        'sms_template' => "Order {{order_number}} is now {{status}}. Track: {{order_url}}"
    ];
    if (defined('SETTINGS_FILE') && file_exists(SETTINGS_FILE)) {
        $raw = @file_get_contents(SETTINGS_FILE);
        $j = @json_decode($raw, true);
        if (is_array($j)) $defaults = array_merge($defaults, $j);
    }
    // Prefer templates/ files if present (per-event templates)
    $tpldir = __DIR__ . '/templates';
    if (is_dir($tpldir)) {
        $map = [
            'email_template' => 'email_status_changed.txt',
            'sms_template'   => 'sms_status_changed.txt'
        ];
        foreach ($map as $key => $fn) {
            $path = $tpldir . '/' . $fn;
            if (file_exists($path) && is_readable($path)) {
                $content = file_get_contents($path);
                if ($content !== false && strlen(trim($content)) > 0) {
                    $defaults[$key] = $content;
                }
            }
        }
    }
    return $defaults;
}

function render_template($tpl, $vars = []) {
    $out = $tpl;
    foreach ($vars as $k => $v) {
        $out = str_replace('{{' . $k . '}}', $v, $out);
    }
    return $out;
}

/* ---------------- Symfony Mailer ---------------- */
function symfony_mailer_send($to, $subject, $body) {
    $autoload = __DIR__ . '/vendor/autoload.php';
    if (!file_exists($autoload)) return false;
    require_once $autoload;

    $host = defined('SMTP_HOST') ? SMTP_HOST : '';
    $port = defined('SMTP_PORT') ? SMTP_PORT : 587;
    $user = defined('SMTP_USER') ? SMTP_USER : '';
    $pass = defined('SMTP_PASS') ? SMTP_PASS : '';

    if (empty($host)) return false;

    $user_enc = rawurlencode($user);
    $pass_enc = rawurlencode($pass);

    if (!empty($user)) {
        $dsn = "smtp://{$user_enc}:{$pass_enc}@{$host}:{$port}";
    } else {
        $dsn = "smtp://{$host}:{$port}";
    }

    if (!defined('SMTP_ENCRYPTION')) {
        if (intval($port) === 465) $dsn .= '?encryption=ssl';
        elseif (intval($port) === 587) $dsn .= '?encryption=tls';
    } else {
        $dsn .= '?encryption=' . rawurlencode(SMTP_ENCRYPTION);
    }

    // normalize newlines: convert backslash-n sequences to real newlines
    $body_for_email = str_replace(["\\r","\\n"], ["","\\n"], $body); // convert escaped to \n
    $body_for_email = str_replace(["\\\\n","\\n"], ["\\n","\n"], $body_for_email); // unescape
    $body_for_email = str_replace(["\\r"], ["\r"], $body_for_email);
    // final cleanup: ensure no literal "\n" left
    $body_for_email = str_replace("\\n", "\n", $body_for_email);

    try {
        $transport = Symfony\Component\Mailer\Transport::fromDsn($dsn);
        $mailer = new Symfony\Component\Mailer\Mailer($transport);

        $fromEmail = defined('SMTP_FROM_EMAIL') ? SMTP_FROM_EMAIL : 'no-reply@localhost';
        $fromName  = defined('SMTP_FROM_NAME') ? SMTP_FROM_NAME : 'Runners';

        $email = (new Symfony\Component\Mime\Email())
            ->from(sprintf('%s <%s>', $fromName, $fromEmail))
            ->to($to)
            ->subject($subject)
            ->text($body_for_email);

        $mailer->send($email);
        safe_log('email_errors.txt', "Symfony send OK to {$to} (subject: {$subject})");
        // Save debug body
        @file_put_contents(__DIR__ . '/data/email_debug_last.txt', $body_for_email);
        return true;
    } catch (\Throwable $e) {
        safe_log('email_errors.txt', 'Symfony Mailer error: ' . $e->getMessage());
        @file_put_contents(__DIR__ . '/data/email_debug_last.txt', $body_for_email);
        return false;
    }
}

/* --------------- PHP mail fallback ---------------- */
function php_mail_fallback_send($to, $subject, $body) {
    // Normalize newlines like above
    $body_for_email = str_replace(["\\r","\\n"], ["","\\n"], $body);
    $body_for_email = str_replace(["\\\\n","\\n"], ["\\n","\n"], $body_for_email);
    $body_for_email = str_replace("\\n", "\n", $body_for_email);

    $fromEmail = defined('SMTP_FROM_EMAIL') ? SMTP_FROM_EMAIL : 'no-reply@localhost';
    $fromName  = defined('SMTP_FROM_NAME') ? SMTP_FROM_NAME : 'Runners';
    $headers = "From: {$fromName} <{$fromEmail}>\r\n";
    $headers .= "Content-Type: text/plain; charset=utf-8\r\n";

    @file_put_contents(__DIR__ . '/data/email_debug_last.txt', $body_for_email);
    @mail($to, $subject, $body_for_email, $headers, "-f{$fromEmail}");
    safe_log('email_errors.txt', "mail() fallback called for {$to} (subject: {$subject})");
    return true;
}

function send_email_receipt($to, $subject, $body) {
    // if recipient empty, don't attempt
    if (empty($to) || !filter_var($to, FILTER_VALIDATE_EMAIL)) {
        safe_log('email_errors.txt', "Not sending email: invalid recipient '{$to}'");
        return false;
    }

    // prefer symfony if available
    if (file_exists(__DIR__ . '/vendor/autoload.php')) {
        $ok = symfony_mailer_send($to, $subject, $body);
        if ($ok) return true;
        // else fall back
    }
    return php_mail_fallback_send($to, $subject, $body);
}

/* ---------------- Twilio helpers ---------------- */
function log_twilio($msg) {
    safe_log('twilio_log.txt', $msg);
}

function send_twilio_message($to, $message) {
    // ensure Twilio config present
    if (!defined('TWILIO_ACCOUNT_SID') || !defined('TWILIO_AUTH_TOKEN') || !defined('TWILIO_FROM_NUMBER') ||
        empty(TWILIO_ACCOUNT_SID) || empty(TWILIO_AUTH_TOKEN) || empty(TWILIO_FROM_NUMBER)) {
        log_twilio('Twilio not configured - skipping send');
        return false;
    }

    // ensure message not empty
    if (!isset($message) || trim($message) === '') {
        log_twilio('Twilio: not sending empty message to ' . $to);
        // save debug file for inspection
        @file_put_contents(__DIR__ . '/data/twilio_debug_last.txt', '');
        return false;
    }

    // Prepare payload and normalize To
    $payload = ['Body' => $message, 'To' => $to, 'From' => TWILIO_FROM_NUMBER];

    $url = 'https://api.twilio.com/2010-04-01/Accounts/' . TWILIO_ACCOUNT_SID . '/Messages.json';
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($payload));
    curl_setopt($ch, CURLOPT_USERPWD, TWILIO_ACCOUNT_SID . ':' . TWILIO_AUTH_TOKEN);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $resp = curl_exec($ch);
    $info = curl_getinfo($ch);
    $http = $info['http_code'] ?? 0;
    $logEntry = json_encode(['to'=>$to,'from'=>TWILIO_FROM_NUMBER,'body'=>$message,'http_code'=>$http,'response'=>$resp]);
    log_twilio($logEntry);
    // save the last body attempted
    @file_put_contents(__DIR__ . '/data/twilio_debug_last.txt', $message);
    curl_close($ch);

    return ($http >= 200 && $http < 300);
}

/* ------------- notify_order_status_changed ------------- */
function notify_order_status_changed($order_id, $new_status) {
    try {
        $db = new PDO('sqlite:' . DB_FILE);
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch (\Throwable $e) {
        safe_log('email_errors.txt', 'DB open error: ' . $e->getMessage());
        return false;
    }

    $stmt = $db->prepare('SELECT * FROM orders WHERE id = ? LIMIT 1');
    $stmt->execute([$order_id]);
    $order = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$order) {
        safe_log('email_errors.txt', "Order {$order_id} not found");
        return false;
    }

    $items = json_decode($order['items'], true) ?: [];
    $lines = [];
    foreach ($items as $it) {
        $name = isset($it['name']) ? $it['name'] : 'item';
        $qty  = intval($it['qty'] ?? 0);
        $line = floatval($it['line'] ?? 0.0);
        $lines[] = sprintf('%s x%d (R%s)', $name, $qty, number_format($line, 2));
    }

    $vars = [
        'order_number'  => $order['order_number'] ?? '',
        'status'        => $new_status,
        'customer_name' => $order['customer_name'] ?? '',
        'phone'         => $order['phone'] ?? '',
        'email'         => $order['email'] ?? '',
        'address'       => $order['address'] ?? '',
        'items'         => implode("\n", $lines),
        'total'         => 'R ' . number_format(floatval($order['total'] ?? 0), 2),
        'order_url'     => (defined('BASE_URL') ? rtrim(BASE_URL, '/') : '') . '/job_status.php?token=' . ($order['token'] ?? '')
    ];

    $settings = load_settings();

    // ---------- Email ----------
    if (!empty($settings['email_enabled']) && !empty($order['email'])) {
        // choose template file or fallback
        $tplfile = __DIR__ . '/templates/email_status_changed.txt';
        if (file_exists($tplfile) && is_readable($tplfile)) {
            $tpl = file_get_contents($tplfile);
        } else {
            $tpl = $settings['email_template'] ?? "Hello {{customer_name}},\n\nYour order {{order_number}} status: {{status}}\n\nTrack: {{order_url}}\n\nThanks,\nRunners";
        }
        $body = render_template($tpl, $vars);
        // write debug file for admin inspection
        @file_put_contents(__DIR__ . '/data/email_debug_last.txt', $body);

        if (trim($body) === '') {
            safe_log('email_errors.txt', "Not sending email for order {$order_id}: rendered body is empty");
        } else {
            $subject = 'Order ' . ($order['order_number'] ?? '') . ' status: ' . $new_status;
            @send_email_receipt($order['email'], $subject, $body);
        }
    } else {
        safe_log('email_errors.txt', "Email disabled or order has no email for order {$order_id}");
    }

    // ---------- SMS/WhatsApp via Twilio ----------
    if (!empty($settings['sms_enabled']) && !empty($order['phone'])) {
        $tplfile_sms = __DIR__ . '/templates/sms_status_changed.txt';
        if (file_exists($tplfile_sms) && is_readable($tplfile_sms)) {
            $sms_tpl = file_get_contents($tplfile_sms);
        } else {
            $sms_tpl = $settings['sms_template'] ?? "Order {{order_number}} is now {{status}}. Track: {{order_url}}";
        }
        $sms_body = render_template($sms_tpl, $vars);
        // write twilio debug file
        @file_put_contents(__DIR__ . '/data/twilio_debug_last.txt', $sms_body);

        // Normalize recipient
        $to = trim($order['phone']);
        $to = preg_replace('/\s+/', '', $to);
        if (strpos((defined('TWILIO_FROM_NUMBER') ? TWILIO_FROM_NUMBER : ''), 'whatsapp:') === 0) {
            // if from is whatsapp, Twilio expects to: 'whatsapp:+<num-without-spaces>'
            if (strpos($to, '+') === 0) $to = substr($to, 1);
            $to_send = 'whatsapp:' . $to;
        } else {
            if (strpos($to, '+') !== 0) $to = '+' . $to;
            $to_send = $to;
        }

        if (trim($sms_body) === '') {
            log_twilio("Not sending empty SMS for order {$order_id} to {$to_send}");
        } else {
            @send_twilio_message($to_send, $sms_body);
        }
    } else {
        log_twilio("SMS disabled or no phone for order {$order_id}");
    }

    return true;
}
?>
