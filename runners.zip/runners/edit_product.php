<?php
require 'config.php';
require 'admin_auth.php';
admin_require_login();

$id = intval($_GET['id'] ?? 0);

$db = new PDO("sqlite:" . DB_FILE);
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$stmt = $db->prepare("SELECT * FROM products WHERE id = ?");
$stmt->execute([$id]);
$product = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$product) { echo "Product not found"; exit; }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $desc = trim($_POST['description']);
    $price = floatval($_POST['price']);
    $sku = trim($_POST['sku']);
    $image = $product['image'];

    if (!empty($_FILES['image']['name'])) {
        $image = time() . "_" . basename($_FILES["image"]["name"]);
        move_uploaded_file($_FILES["image"]["tmp_name"], "uploads/" . $image);
    }

    $stmt = $db->prepare("UPDATE products SET name=?, description=?, price=?, sku=?, image=? WHERE id=?");
    $stmt->execute([$name, $desc, $price, $sku, $image, $id]);

    header("Location: products.php?updated=1");
    exit;
}
?>
<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>Edit Product</title>
</head>
<body>
<h1>Edit Product</h1>
<form method="post" enctype="multipart/form-data">
    <label>Name<br><input name="name" value="<?=htmlspecialchars($product['name'])?>"></label><br>
    <label>Description<br><textarea name="description"><?=htmlspecialchars($product['description'])?></textarea></label><br>
    <label>Price<br><input name="price" type="number" step="0.01" value="<?=$product['price']?>"></label><br>
    <label>SKU<br><input name="sku" value="<?=$product['sku']?>"></label><br>
    <label>Image<br><input type="file" name="image"></label><br>
    <p>Current: <?=$product['image']?></p>
    <button>Save Changes</button>
</form>
</body>
</html>
