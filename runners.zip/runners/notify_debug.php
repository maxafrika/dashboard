<?php
// notify_debug.php - debug helper for notifications
// Upload to project root and call in browser like ?id=123 (order id).
// WARNING: This will attempt to send real messages if your config has valid creds.
// Remove when done.

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/notifications.php';

ini_set('display_errors',1);
ini_set('display_startup_errors',1);
error_reporting(E_ALL);

$order_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

echo "<h2>Notification debug</h2>";
echo "<p>Script dir: " . htmlspecialchars(__DIR__) . "</p>";
echo "<p>PHP version: " . phpversion() . "</p>";

// show settings file and templates
$tpldir = __DIR__ . '/templates';
$settings_file = defined('SETTINGS_FILE') ? SETTINGS_FILE : __DIR__ . '/data/settings.json';
echo "<h3>Settings file</h3>";
if (file_exists($settings_file)) {
    echo "<pre>" . htmlspecialchars(file_get_contents($settings_file)) . "</pre>";
} else {
    echo "<p><em>Settings file missing: " . htmlspecialchars($settings_file) . "</em></p>";
}

echo "<h3>Template files (raw)</h3>";
foreach (glob($tpldir . '/*.txt') as $f) {
    echo "<h4>" . htmlspecialchars(basename($f)) . "</h4><pre style='background:#f6f6f6;padding:8px;'>" . htmlspecialchars(file_get_contents($f)) . "</pre>";
}

// show last lines of logs
echo "<h3>Logs: data/email_errors.txt (tail 4000)</h3>";
if (file_exists(__DIR__.'/data/email_errors.txt')) {
    $s = file_get_contents(__DIR__.'/data/email_errors.txt');
    echo "<pre>" . htmlspecialchars(substr($s, -4000)) . "</pre>";
} else echo "<p>no email_errors.txt</p>";

echo "<h3>Logs: data/twilio_log.txt (tail 4000)</h3>";
if (file_exists(__DIR__.'/data/twilio_log.txt')) {
    $s = file_get_contents(__DIR__.'/data/twilio_log.txt');
    echo "<pre>" . htmlspecialchars(substr($s, -4000)) . "</pre>";
} else echo "<p>no twilio_log.txt</p>";

// load settings via notifications.php helper
$settings = load_settings();
echo "<h3>Resolved settings (load_settings())</h3><pre>" . htmlspecialchars(print_r($settings, true)) . "</pre>";

// order lookup
if ($order_id) {
    try {
        $db = new PDO('sqlite:' . DB_FILE);
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $stmt = $db->prepare('SELECT * FROM orders WHERE id = ? LIMIT 1');
        $stmt->execute([$order_id]);
        $order = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$order) {
            echo "<p style='color:red'>Order ID $order_id not found</p>";
            exit;
        }
    } catch (Throwable $e) {
        echo "<p style='color:red'>DB error: " . htmlspecialchars($e->getMessage()) . "</p>";
        exit;
    }

    echo "<h3>Order data (raw)</h3><pre>" . htmlspecialchars(print_r($order, true)) . "</pre>";

    // prepare vars like notify_order_status_changed()
    $items = json_decode($order['items'], true) ?: [];
    $lines = [];
    foreach ($items as $it) {
        $lines[] = (isset($it['name']) ? $it['name'] : 'item') . ' x' . intval($it['qty'] ?? 0) . ' (R' . number_format(floatval($it['line'] ?? 0),2) . ')';
    }
    $vars = [
        'order_number' => $order['order_number'] ?? '',
        'status' => $order['status'] ?? '',
        'customer_name' => $order['customer_name'] ?? '',
        'phone' => $order['phone'] ?? '',
        'email' => $order['email'] ?? '',
        'address' => $order['address'] ?? '',
        'items' => implode("\n", $lines),
        'total' => 'R ' . number_format(floatval($order['total'] ?? 0),2),
        'order_url' => (defined('BASE_URL') ? rtrim(BASE_URL, '/') : '') . '/job_status.php?token=' . ($order['token'] ?? '')
    ];

    echo "<h3>Rendered template chosen for email</h3>";
    // pick template file like notifications does
    $tplfile = __DIR__ . '/templates/email_status_changed.txt';
    if (file_exists($tplfile)) {
        $tpl = file_get_contents($tplfile);
    } else {
        $tpl = $settings['email_template'] ?? "Hello {{customer_name}},\n\nYour order {{order_number}} status: {{status}}\n\nTrack: {{order_url}}\n\nThanks,\nRunners";
    }
    $rendered = render_template($tpl, $vars);
    echo "<pre style='background:#eee;padding:8px;'>" . htmlspecialchars($rendered) . "</pre>";

    // save a debug file to data to see what exactly is sent
    @file_put_contents(__DIR__ . '/data/email_debug_last.txt', $rendered);

    // attempt to send email (only if email_enabled and order email exists)
    echo "<h3>Attempt send email?</h3>";
    if (!empty($settings['email_enabled']) && !empty($order['email'])) {
        echo "<p>Calling send_email_receipt( to: " . htmlspecialchars($order['email']) . " )</p>";
        $res = @send_email_receipt($order['email'], 'Debug: order ' . ($order['order_number'] ?? ''), $rendered);
        echo "<p>send_email_receipt returned: " . ($res ? 'true' : 'false') . "</p>";
    } else {
        echo "<p style='color:orange'>Email notifications disabled or order email missing.</p>";
    }

    // Attempt Twilio send
    echo "<h3>Attempt Twilio send?</h3>";
    if (!empty($settings['sms_enabled']) && !empty($order['phone'])) {
        $tplfile_sms = __DIR__ . '/templates/sms_status_changed.txt';
        if (file_exists($tplfile_sms)) $sms_tpl = file_get_contents($tplfile_sms); else $sms_tpl = $settings['sms_template'] ?? "Order {{order_number}} is now {{status}}. Track: {{order_url}}";
        $sms_body = render_template($sms_tpl, $vars);
        @file_put_contents(__DIR__ . '/data/twilio_debug_last.txt', $sms_body);

        // normalize number
        $to = trim($order['phone']);
        $to = preg_replace('/\s+/', '', $to);
        if (strpos(TWILIO_FROM_NUMBER ?? '', 'whatsapp:') === 0) {
            if (strpos($to, '+') === 0) $to = substr($to,1);
            $to = 'whatsapp:' . $to;
        } else {
            if (strpos($to, '+') !== 0) $to = '+' . $to;
        }

        echo "<p>Sending to Twilio To: " . htmlspecialchars($to) . "</p>";
        $ok = @send_twilio_message($to, $sms_body);
        echo "<p>send_twilio_message returned: " . ($ok ? 'true' : 'false') . "</p>";
    } else {
        echo "<p style='color:orange'>SMS notifications disabled or order phone missing.</p>";
    }

    echo "<h3>Done — check data/email_debug_last.txt and data/twilio_debug_last.txt for raw bodies.</h3>";
} else {
    echo "<p>No order id given. Provide ?id=ORDERID to debug a specific order.</p>";
    echo "<p>Alternatively visit settings.php and use Send Test Email to test templating.</p>";
}
?>
