<?php
require 'config.php';
require 'admin_auth.php';

if (admin_is_logged_in()) {
    header("Location: admin.php");
    exit;
}

$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pass = trim($_POST['password'] ?? '');
    if (admin_check_password($pass)) {
        $_SESSION['runners_admin'] = true;
        header("Location: admin.php");
        exit;
    } else {
        $error = "Invalid password";
    }
}
?>
<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>Admin Login - Runners</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="container">
    <h1>Admin Login</h1>
    <?php if ($error) echo "<p style='color:red'>$error</p>"; ?>
    <form method="post">
        <label>Password<br>
            <input type="password" name="password">
        </label>
        <p><button>Login</button></p>
    </form>
</div>
</body>
</html>
