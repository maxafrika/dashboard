<?php
require 'config.php';
require_once 'notifications.php';

// The number you want to send the test message to
$test_to = '+27 83 714 3474'; // <-- Your number included here

// Note: If you were testing WhatsApp, you would use the format 'whatsapp:+27603186042'
// But for standard SMS, the E.164 format ('+countrycode number') is correct.

// Define the message content
$message = 'Runners test message - ignore';

// Attempt to send the message using the defined function (assuming it's in notifications.php)
// The function is assumed to be `send_twilio_message($to, $body)`
$result = send_twilio_message($test_to, $message);

echo '<pre>';
echo 'To: ' . htmlspecialchars($test_to) . "\n";
echo 'Result: ' . ($result ? 'Sent (HTTP 2xx)' : 'Failed') . "\n";

// Display the log file content if available
$log = @file_get_contents(__DIR__ . '/data/twilio_log.txt');
if ($log) {
    echo "\nTwilio log:\n" . htmlspecialchars($log);
}

echo '</pre>';
?>