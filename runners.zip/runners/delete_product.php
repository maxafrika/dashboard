<?php
require 'config.php';
require 'admin_auth.php';
admin_require_login();

$id = intval($_GET['id'] ?? 0);

$db = new PDO("sqlite:" . DB_FILE);
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$stmt = $db->prepare("DELETE FROM products WHERE id=?");
$stmt->execute([$id]);

header("Location: products.php?deleted=1");
exit;
?>
