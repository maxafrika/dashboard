<?php
// settings.php - updated to prefer template files and remove legacy settings.json keys
require 'config.php';
require 'admin_auth.php';
admin_require_login();
require_once 'notifications.php';

// Ensure templates dir exists
$tpldir = __DIR__ . '/templates';
if (!is_dir($tpldir)) mkdir($tpldir, 0755, true);

$settings_file = defined('SETTINGS_FILE') ? SETTINGS_FILE : __DIR__ . '/data/settings.json';

// Template list
$templates = [
    'email_order_received.txt'    => 'Order Received (Customer)',
    'email_status_changed.txt'    => 'Order Status Changed (Customer)',
    'email_order_completed.txt'   => 'Order Completed (Customer)',
    'email_invoice.txt'           => 'Invoice (Customer)',
    'sms_status_changed.txt'      => 'SMS: Status Changed (Customer)'
];

// Load saved toggles if any (but we will always use files for template bodies)
$saved = [];
if (file_exists($settings_file)) {
    $s = @json_decode(file_get_contents($settings_file), true);
    if (is_array($s)) $saved = $s;
}

// Ensure the template files exist (create default if empty)
$defaults = [
    'email_order_received.txt' => "Hello {{customer_name}},\n\nThank you for your order {{order_number}}. We will process it shortly.\n\nItems:\n{{items}}\n\nTotal: {{total}}\n\nTrack: {{order_url}}\n\nThanks,\nRunners\n",
    'email_status_changed.txt' => "Hello {{customer_name}},\n\nYour order {{order_number}} status is now: {{status}}.\n\nTrack: {{order_url}}\n\nThanks,\nRunners\n",
    'email_order_completed.txt' => "Hello {{customer_name}},\n\nYour order {{order_number}} is completed.\n\nThanks,\nRunners\n",
    'email_invoice.txt' => "Hello {{customer_name}},\n\nAttached: invoice for {{order_number}}. Total: {{total}}.\n\nRegards,\nRunners\n",
    'sms_status_changed.txt' => "Order {{order_number}} is now {{status}}. Track: {{order_url}}"
];

foreach ($templates as $fn => $label) {
    $p = $tpldir . '/' . $fn;
    if (!file_exists($p) || filesize($p) === 0) {
        file_put_contents($p, isset($defaults[$fn]) ? $defaults[$fn] : "");
    }
}

// Save POST: write each template file and save toggles to settings.json (no template bodies)
$notice = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !isset($_POST['action'])) {
    // save toggles
    $saved['email_enabled'] = isset($_POST['email_enabled']) ? true : false;
    $saved['sms_enabled'] = isset($_POST['sms_enabled']) ? true : false;

    // write each template file
    foreach ($templates as $fn => $label) {
        $field = 'tpl_' . $fn;
        $content = isset($_POST[$field]) ? $_POST[$field] : '';
        $content = str_replace(["\r\n", "\r"], ["\n", ""], $content);
        file_put_contents($tpldir . '/' . $fn, $content);
    }

    // Remove legacy keys if present in settings.json to avoid future confusion
    if (isset($saved['email_template'])) unset($saved['email_template']);
    if (isset($saved['sms_template'])) unset($saved['sms_template']);

    if (!is_dir(dirname($settings_file))) mkdir(dirname($settings_file), 0755, true);
    file_put_contents($settings_file, json_encode($saved, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
    $notice = "Settings and templates saved to files (templates/).";
}

// Load template content from files for editing UI
$current_templates = [];
foreach ($templates as $fn => $label) {
    $path = $tpldir . '/' . $fn;
    $current_templates[$fn] = file_exists($path) ? file_get_contents($path) : '';
}

// UI toggles values
$cur_email_enabled = !empty($saved['email_enabled']);
$cur_sms_enabled = !empty($saved['sms_enabled']);

?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Settings & Templates - Runners</title>
<link rel='stylesheet' href='assets/style.css'>
<style>
body{font-family:Arial,Helvetica,sans-serif;margin:20px}
.container{max-width:980px;margin:0 auto}
textarea{width:100%;min-height:160px;font-family:monospace}
.notice{background:#e6ffed;border:1px solid #b7f0c1;padding:8px;margin-bottom:12px}
.err{background:#ffe6e6;border:1px solid #f0b7b7;padding:8px;margin-bottom:12px}
.small{font-size:90%;color:#555}
.tpl-label{font-weight:700;margin-top:8px}
.preview{white-space:pre-wrap;background:#f6f6f6;padding:10px;border:1px solid #ddd}
.path{font-size:90%;color:#666}
.nav a:hover { text-decoration:underline; }
.nav a { color:#fff; margin-right:20px; text-decoration:none; }
</style>
</head>
<body>
<div class="nav" style="background:#222;padding:12px;margin:-20px -20px 20px -20px;">
    <a href="admin.php">Dashboard</a>
    <a href="admin_pages/products.php">Products</a>
    <a href="admin_pages/customers.php">Customers</a>
    <a href="admin_pages/orders.php">Orders</a>
    <a href="admin_pages/completed.php">Completed</a>
    <a href="admin_pages/inbox.php">Inbox</a>
    <a href="settings.php" style="color:#0f0;font-weight:bold">Settings</a>
    <a href="admin_logout.php" style="float:right;color:#f55">Logout</a>
</div>

<div class="container">
    <h1>Notification Settings & Templates</h1>
    <?php if ($notice): ?><div class="notice"><?=htmlspecialchars($notice)?></div><?php endif; ?>

    <p class="small">Template files are stored at: <code><?=htmlspecialchars($tpldir)?></code></p>
    <p class="small">Settings file: <code><?=htmlspecialchars($settings_file)?></code></p>

    <form method="post">
        <h2>Notification toggles</h2>
        <label><input type="checkbox" name="email_enabled" <?= $cur_email_enabled ? 'checked' : '' ?>> Enable Email notifications</label><br>
        <label><input type="checkbox" name="sms_enabled" <?= $cur_sms_enabled ? 'checked' : '' ?>> Enable SMS / WhatsApp notifications</label>

        <h2>Templates</h2>
        <p class="small">Edit templates below. Use these variables: <code>{{order_number}}</code>, <code>{{customer_name}}</code>, <code>{{status}}</code>, <code>{{items}}</code>, <code>{{total}}</code>, <code>{{order_url}}</code>.</p>

        <?php foreach ($templates as $file => $label): ?>
            <div class="tpl-label"><?=htmlspecialchars($label)?> — <small><?=htmlspecialchars($file)?></small></div>
            <div class="path">File: <?=htmlspecialchars($tpldir . '/' . $file)?></div>
            <textarea name="<?= 'tpl_' . htmlspecialchars($file) ?>"><?= htmlspecialchars($current_templates[$file]) ?></textarea>
            <p><button type="submit" name="preview_tpl" value="<?= htmlspecialchars($file) ?>">Preview this template</button></p>
        <?php endforeach; ?>

        <p><button>Save templates & settings</button></p>
    </form>

    <?php if (!empty($_POST['preview_tpl'])): 
        $which = $_POST['preview_tpl'];
        $tplfile = $tpldir . '/' . $which;
        $tpl = file_exists($tplfile) ? file_get_contents($tplfile) : '';
        $sample = [
            'order_number' => 'ORD123456', 'customer_name' => 'Debug User', 'status' => 'processing',
            'items' => "Tea Towel x1 (R29.99)\nMug x2 (R59.98)", 'total' => 'R 89.97',
            'order_url' => rtrim(defined('BASE_URL') ? BASE_URL : '', '/') . '/job_status.php?token=deadbeef'
        ];
        $out = $tpl;
        foreach ($sample as $k => $v) $out = str_replace('{{'.$k.'}}', $v, $out);
    ?>
        <h3>Preview</h3>
        <div class="preview"><?= nl2br(htmlspecialchars($out)) ?></div>
    <?php endif; ?>

    <hr>
    <h2>Send a test email</h2>
    <form method="post" onsubmit="document.getElementById('action').value='send_test'">
        <input type="hidden" id="action" name="action" value="">
        <label>Recipient email<br><input type="email" name="test_email" style="width:350px"></label><br>
        <label>Template to send<br>
            <select name="test_template">
                <?php foreach ($templates as $file => $label): ?>
                    <option value="<?=htmlspecialchars($file)?>"><?=htmlspecialchars($label).' — '.htmlspecialchars($file)?></option>
                <?php endforeach; ?>
            </select>
        </label><br><br>
        <button type="submit" onclick="document.getElementById('action').value='send_test'">Send Test Email</button>
    </form>

    <hr>
    <p class="small">Templates are stored in <code>/templates/</code>. Settings are saved to <code><?=htmlspecialchars($settings_file)?></code>.</p>
</div>
</body>
</html>
