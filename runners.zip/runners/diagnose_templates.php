<?php
// diagnose_templates.php - buffered, safe to include other admin files
// Upload this next to settings.php and open it in your browser.

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Start output buffering as the first action to avoid "headers already sent" problems
ob_start();

echo "<h2>Templates diagnostic</h2>";

$base = __DIR__;
echo "<p><strong>Script directory:</strong> " . htmlspecialchars($base) . "</p>";

$tpldir = $base . '/templates';
$settings_file = defined('SETTINGS_FILE') ? SETTINGS_FILE : ($base . '/data/settings.json');

echo "<p><strong>Templates dir:</strong> " . htmlspecialchars($tpldir) . "</p>";
echo "<p><strong>Settings file path:</strong> " . htmlspecialchars($settings_file) . "</p>";

function perms_str($file) {
    $perms = @fileperms($file);
    if ($perms === false) return 'n/a';
    return substr(sprintf('%o', $perms), -4);
}

// Check templates directory
if (!file_exists($tpldir)) {
    echo "<p style='color:orange'><strong>Notice:</strong> templates/ directory does not exist.</p>";
} else {
    echo "<h3>templates/ directory exists</h3>";
    echo "<p>Readable: " . (is_readable($tpldir) ? 'yes' : '<strong>NO</strong>') . "</p>";
    echo "<p>Writable: " . (is_writable($tpldir) ? 'yes' : '<strong>NO</strong>') . "</p>";
    echo "<p>Permissions: " . htmlspecialchars(perms_str($tpldir)) . "</p>";
}

// List files
if (is_dir($tpldir)) {
    echo "<h3>Template files</h3><table border='1' cellpadding='6'><tr><th>File</th><th>Size</th><th>Mod time</th><th>Readable</th><th>Writable</th><th>Perms</th></tr>";
    foreach (glob($tpldir . '/*') as $f) {
        $name = basename($f);
        $size = @filesize($f);
        $mtime = @date('c', @filemtime($f));
        echo "<tr><td>" . htmlspecialchars($name) . "</td><td>" . htmlspecialchars($size) . "</td><td>" . htmlspecialchars($mtime) . "</td><td>" . (is_readable($f)?'yes':'<strong>NO</strong>') . "</td><td>" . (is_writable($f)?'yes':'<strong>NO</strong>') . "</td><td>" . htmlspecialchars(perms_str($f)) . "</td></tr>";
    }
    echo "</table>";
}

// Show current template contents (first 2 files)
if (is_dir($tpldir)) {
    echo "<h3>Contents preview (first 2 files)</h3>";
    $list = array_slice(glob($tpldir . '/*'), 0, 2);
    foreach ($list as $f) {
        echo "<h4>" . htmlspecialchars(basename($f)) . "</h4><pre style='background:#f6f6f6;padding:8px;'>" . htmlspecialchars(file_get_contents($f)) . "</pre>";
    }
}

// Show settings.json
echo "<h3>Settings file</h3>";
if (!file_exists($settings_file)) {
    echo "<p style='color:orange'>Settings file does not exist: " . htmlspecialchars($settings_file) . "</p>";
} else {
    echo "<p>Exists. Readable: " . (is_readable($settings_file)?'yes':'<strong>NO</strong>') . ". Writable: " . (is_writable($settings_file)?'yes':'<strong>NO</strong>') . ". Perms: " . htmlspecialchars(perms_str($settings_file)) . "</p>";
    echo "<pre style='background:#f6f6f6;padding:8px;'>" . htmlspecialchars(@file_get_contents($settings_file)) . "</pre>";
}

// Attempt to write a test file into templates/
$testFile = $tpldir . '/.write_test_' . time() . '.txt';
echo "<h3>Write test</h3>";
$wrote = @file_put_contents($testFile, "write test at " . date('c') . "\n");
if ($wrote === false) {
    echo "<p style='color:red'><strong>Write test FAILED.</strong> PHP could not write to templates/.</p>";
    echo "<p>Last PHP error (if any):</p><pre>";
    $err = error_get_last();
    echo htmlspecialchars(print_r($err, true));
    echo "</pre>";
} else {
    echo "<p style='color:green'><strong>Write test SUCCEEDED.</strong> Wrote file: " . htmlspecialchars(basename($testFile)) . " (" . htmlspecialchars($wrote) . " bytes)</p>";
    echo "<p>File contents:</p><pre>" . htmlspecialchars(file_get_contents($testFile)) . "</pre>";
    @unlink($testFile);
}

// Quick check: is settings.php process actually writing templates via same code path?
echo "<h3>Quick sanity check: attempt to save via same function used in settings.php</h3>";
$sampleFile = $tpldir . '/diag_sample_save.txt';
$sampleContent = "diag-sample " . date('c');
$ok = @file_put_contents($sampleFile, $sampleContent);
if ($ok === false) {
    echo "<p style='color:red'>Sample save failed writing $sampleFile</p>";
} else {
    echo "<p style='color:green'>Sample save succeeded writing $sampleFile (" . htmlspecialchars($ok) . " bytes). Content preview:</p><pre>" . htmlspecialchars(file_get_contents($sampleFile)) . "</pre>";
    @unlink($sampleFile);
}

// flush buffer to output now (so headers can be sent if needed by included pages later)
ob_end_flush();

echo "<hr><p>Recommended fixes if write failed:</p><ol>
<li>Set permissions on templates/ and data/ to be writable by webserver. In cPanel File Manager set CHMOD to 755 or 775 for those directories.</li>
<li>Ensure directories exist: create /templates and /data if missing.</li>
<li>If you have SSH/cPanel terminal, run: <code>chmod -R 775 templates data; chown -R <your-cpanel-user>:<your-cpanel-user> templates data</code></li>
<li>After permission changes, retry editing and saving in settings.php.</li>
</ol>";

echo "<p>If you paste the whole output of this page here I will give precise next steps.</p>";
?>
