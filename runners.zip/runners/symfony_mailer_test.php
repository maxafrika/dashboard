<?php
require 'config.php';
require 'notifications.php';

$to = isset($_GET['to']) ? $_GET['to'] : (isset($argv[1]) ? $argv[1] : '');
if (!$to) {
    echo "Usage: php symfony_mailer_test.php +2776.... or visit ?to=+2776...\n";
    exit;
}

$subject = "Runners Symfony Mailer test";
$body = "This is a test email from Runners at " . date('c');

$result = send_email_receipt($to, $subject, $body);

echo "send_email_receipt returned: " . ($result ? "true" : "false") . "\n";
if (file_exists(__DIR__.'/data/email_errors.txt')) {
    echo "\nEmail errors log:\n";
    echo nl2br(htmlspecialchars(file_get_contents(__DIR__.'/data/email_errors.txt')));
}
?>
