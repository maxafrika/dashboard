<?php
require 'config.php';
require 'admin_auth.php';
admin_require_login();

$db = new PDO("sqlite:" . DB_FILE);
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $desc = trim($_POST['description']);
    $price = floatval($_POST['price']);
    $sku = trim($_POST['sku']);
    $image = "";

    if (!empty($_FILES['image']['name'])) {
        $image = time() . "_" . basename($_FILES["image"]["name"]);
        move_uploaded_file($_FILES["image"]["tmp_name"], "uploads/" . $image);
    }

    $stmt = $db->prepare("INSERT INTO products (name, description, price, sku, image) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$name, $desc, $price, $sku, $image]);

    header("Location: products.php?added=1");
    exit;
}
?>
<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>Add Product</title>
</head>
<body>
<h1>Add Product</h1>
<form method="post" enctype="multipart/form-data">
    <label>Name<br><input name="name"></label><br>
    <label>Description<br><textarea name="description"></textarea></label><br>
    <label>Price<br><input name="price" type="number" step="0.01"></label><br>
    <label>SKU<br><input name="sku"></label><br>
    <label>Image<br><input type="file" name="image"></label><br>
    <button>Add Product</button>
</form>
</body>
</html>
