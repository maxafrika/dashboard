<?php
require 'config.php';
require 'notifications.php';
require 'admin_auth.php';
admin_require_login();

$id = intval($_POST['id']);
$status = trim($_POST['status']);

$db = new PDO("sqlite:" . DB_FILE);
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$stmt = $db->prepare("UPDATE orders SET status=? WHERE id=?");
$stmt->execute([$status, $id]);

notify_order_status_changed($id, $status);

header("Location: orders.php?saved=1");
exit;
?>
