<?php
// debug_settings2.php - prints full error details for settings.php includes
ini_set('display_errors','1');
ini_set('display_startup_errors','1');
error_reporting(E_ALL);

echo "<h3>Debug helper (detailed)</h3>";
echo "<p>PHP version: " . phpversion() . "</p>";
echo "<p>Script dir: " . htmlspecialchars(__DIR__) . "</p>";

try {
    include __DIR__ . '/settings.php';
} catch (ParseError $p) {
    echo "<h4>Parse Error</h4><pre>" . htmlspecialchars($p->getMessage()) . "</pre>";
    echo "<pre>In file: " . htmlspecialchars($p->getFile()) . " on line " . $p->getLine() . "</pre>";
} catch (Throwable $e) {
    echo "<h4>Throwable</h4><pre>" . htmlspecialchars($e->getMessage()) . "</pre>";
    echo "<pre>" . htmlspecialchars($e->getTraceAsString()) . "</pre>";
}

if (is_readable(__DIR__ . '/data/email_errors.txt')) {
    echo "<h4>data/email_errors.txt</h4><pre>" . htmlspecialchars(file_get_contents(__DIR__ . '/data/email_errors.txt')) . "</pre>";
}
if (is_readable(__DIR__ . '/data/twilio_log.txt')) {
    echo "<h4>data/twilio_log.txt (tail)</h4><pre>" . htmlspecialchars(substr(file_get_contents(__DIR__ . '/data/twilio_log.txt'), -4000)) . "</pre>";
}
?>
