<?php
define('APP_NAME','Runners');
define('DB_FILE', __DIR__ . '/data/db.sqlite');

// Admin password storage:
// - Recommended: run setup_admin.php to create data/admin.json (hashed password).
// - If you need a fallback (not recommended) you may set ADMIN_PASSWORD_HASH here.
define('ADMIN_PASSWORD_HASH', 'afroking@25'); // or leave empty and use setup_admin.php
// (optional legacy fallback — remove once you have admin.json)
define('ADMIN_PASSWORD', 'afroking@25');

// WhatsApp / contact
define('WHATSAPP_NUMBER', '27603186042'); // e.g. 27601234567 (no +)
define('BASE_URL', 'https://crystalafrica.co.za');

// SMTP (for PHPMailer)
define('SMTP_HOST', 'mail.crystalafrica.co.za');
define('SMTP_PORT', 587);
define('SMTP_USER', 'johannes@crystalafrica.co.za');
define('SMTP_PASS', 'afroking@24');

// Email From (used by PHPMailer and fallback)
define('SMTP_FROM_EMAIL', 'no-reply@crystalafrica.co.za');
define('SMTP_FROM_NAME', 'Runners');
// legacy alias used in older code
define('EMAIL_FROM', SMTP_FROM_EMAIL);
define('EMAIL_FROM_NAME', SMTP_FROM_NAME);

// Twilio for SMS/WhatsApp
define('TWILIO_ACCOUNT_SID', 'AC65bed0e81d142f9d70177840ff782fe8');
define('TWILIO_AUTH_TOKEN', 'e6870e948e995a9b99e3a8152a7747b1');
define('TWILIO_FROM_NUMBER', '+13253780634'); // For WhatsApp use format: whatsapp:+27601234567
define('ENABLE_EMAIL_RECEIPTS', true);
define('ENABLE_SMS', true);

// Settings file
define('SETTINGS_FILE', __DIR__ . '/data/settings.json');
?>
