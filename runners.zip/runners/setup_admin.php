<?php
$pass = "afroking@25"; // <-- your password here
$hash = password_hash($pass, PASSWORD_DEFAULT);
$data = ['password_hash' => $hash, 'created_at' => date('c')];
file_put_contents(__DIR__ . '/data/admin.json', json_encode($data, JSON_PRETTY_PRINT));
echo "Admin user created.";
?>
