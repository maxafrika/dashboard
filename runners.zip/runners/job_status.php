<?php
require 'config.php';
$token = trim($_GET['token'] ?? '');
if ($token === '') { http_response_code(400); echo 'Invalid tracking link'; exit; }
try {
    $db = new PDO('sqlite:' . DB_FILE);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $stmt = $db->prepare('SELECT * FROM orders WHERE token = ? LIMIT 1');
    $stmt->execute([$token]);
    $order = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$order) { http_response_code(404); echo 'Order not found'; exit; }
    $items = json_decode($order['items'], true) ?: [];
} catch (Exception $e) {
    http_response_code(500);
    echo 'Server error';
    exit;
}
?><!doctype html><html><head><meta charset='utf-8'><title>Order <?php echo htmlspecialchars($order['order_number']) ?></title><link rel='stylesheet' href='assets/style.css'></head><body><div class='container'><h1>Order <?php echo htmlspecialchars($order['order_number']) ?></h1><p>Status: <strong><?php echo htmlspecialchars($order['status']) ?></strong></p><p>Placed: <?php echo htmlspecialchars($order['created_at']) ?></p><h3>Items</h3><ul><?php foreach($items as $it) echo '<li>'.htmlspecialchars($it['name']).' x'.intval($it['qty']).' - R '.number_format($it['line'],2).'</li>'; ?></ul><p>Total: R <?php echo number_format($order['total'],2) ?></p><h3>Customer</h3><p><?php echo htmlspecialchars($order['customer_name']) ?><br><?php echo htmlspecialchars($order['phone']) ?></p></div></body></html>