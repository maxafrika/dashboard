<?php
require 'config.php';
require 'admin_auth.php';
if (!admin_is_logged_in()) { header('Location: admin_login.php'); exit; }
require_once 'notifications.php';
$db=new PDO('sqlite:' . DB_FILE);
$orders = $db->query('SELECT * FROM orders ORDER BY created_at DESC LIMIT 20')->fetchAll(PDO::FETCH_ASSOC);
if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['order_id']) && isset($_POST['status'])){
    $stmt=$db->prepare('UPDATE orders SET status=? WHERE id=?');
    $stmt->execute([$_POST['status'], intval($_POST['order_id'])]);
    notify_order_status_changed(intval($_POST['order_id']), $_POST['status']);
    header('Location: admin.php');
    exit;
}
?>
<!doctype html>
<html>
<head>
    <meta charset='utf-8'>
    <title>Admin - Runners</title>
    <style>
        /* Urban Futuristic Admin Theme */
        :root {
          --primary: #00f0ff;
          --secondary: #ff00c8;
          --accent: #00ff9d;
          --dark: #0a0a12;
          --darker: #050508;
          --light: #f0f0f0;
          --gray: #2a2a3a;
          --card-bg: rgba(20, 20, 30, 0.8);
          --glow: 0 0 10px rgba(0, 240, 255, 0.7);
          --transition: all 0.3s ease;
        }

        * {
          margin: 0;
          padding: 0;
          box-sizing: border-box;
          font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
          background-color: var(--dark);
          background-image: 
            radial-gradient(circle at 10% 20%, rgba(0, 240, 255, 0.1) 0%, transparent 20%),
            radial-gradient(circle at 90% 80%, rgba(255, 0, 200, 0.1) 0%, transparent 20%),
            linear-gradient(to bottom, var(--darker), var(--dark));
          color: var(--light);
          min-height: 100vh;
          line-height: 1.6;
        }

        .container {
          max-width: 1400px;
          margin: 0 auto;
          padding: 20px;
        }

        /* Header Styles */
        h1 {
          font-size: 2.5rem;
          margin-bottom: 1.5rem;
          background: linear-gradient(90deg, var(--primary), var(--accent));
          -webkit-background-clip: text;
          background-clip: text;
          color: transparent;
          text-transform: uppercase;
          letter-spacing: 2px;
          text-shadow: var(--glow);
          position: relative;
          display: inline-block;
        }

        h1::after {
          content: '';
          position: absolute;
          bottom: -5px;
          left: 0;
          width: 100%;
          height: 2px;
          background: linear-gradient(90deg, var(--primary), transparent);
        }

        h2 {
          font-size: 1.8rem;
          margin: 1.5rem 0 1rem;
          color: var(--primary);
          border-left: 3px solid var(--secondary);
          padding-left: 10px;
          text-transform: uppercase;
          letter-spacing: 1px;
        }

        /* Navigation Styles */
        .admin-nav {
          display: flex;
          flex-wrap: wrap;
          gap: 10px;
          margin-bottom: 2rem;
          padding: 15px;
          background: var(--card-bg);
          border-radius: 8px;
          box-shadow: 0 0 15px rgba(0, 0, 0, 0.3);
          border: 1px solid rgba(0, 240, 255, 0.1);
        }

        .admin-nav a {
          display: inline-block;
          color: var(--light);
          text-decoration: none;
          padding: 10px 20px;
          border: 1px solid var(--gray);
          border-radius: 4px;
          transition: var(--transition);
          background: rgba(30, 30, 45, 0.7);
          position: relative;
          overflow: hidden;
          z-index: 1;
          flex: 1;
          min-width: 120px;
          text-align: center;
          font-weight: 500;
          text-transform: uppercase;
          letter-spacing: 1px;
          font-size: 0.9rem;
        }

        .admin-nav a::before {
          content: '';
          position: absolute;
          top: 0;
          left: -100%;
          width: 100%;
          height: 100%;
          background: linear-gradient(90deg, transparent, rgba(0, 240, 255, 0.2), transparent);
          transition: var(--transition);
          z-index: -1;
        }

        .admin-nav a:hover {
          color: var(--primary);
          border-color: var(--primary);
          box-shadow: var(--glow);
          transform: translateY(-2px);
        }

        .admin-nav a:hover::before {
          left: 100%;
        }

        /* Dashboard Section */
        .dashboard-section {
          background: var(--card-bg);
          border-radius: 8px;
          padding: 20px;
          margin-bottom: 2rem;
          box-shadow: 0 0 20px rgba(0, 0, 0, 0.4);
          border: 1px solid rgba(0, 240, 255, 0.1);
        }

        /* Table Styles */
        .table-container {
          overflow-x: auto;
          border-radius: 6px;
          margin-top: 1rem;
        }

        .table {
          width: 100%;
          border-collapse: collapse;
          background: var(--card-bg);
          border-radius: 8px;
          overflow: hidden;
          box-shadow: 0 0 20px rgba(0, 0, 0, 0.5);
          margin-bottom: 2rem;
        }

        .table th {
          background: linear-gradient(to right, var(--darker), var(--gray));
          color: var(--primary);
          padding: 15px;
          text-align: left;
          text-transform: uppercase;
          letter-spacing: 1px;
          font-weight: 600;
          border-bottom: 2px solid var(--primary);
          font-size: 0.9rem;
        }

        .table td {
          padding: 12px 15px;
          border-bottom: 1px solid rgba(255, 255, 255, 0.1);
          transition: var(--transition);
        }

        .table tr:hover td {
          background: rgba(0, 240, 255, 0.05);
        }

        .table tr:last-child td {
          border-bottom: none;
        }

        /* Customer Info Styles */
        .customer-info {
          display: flex;
          flex-direction: column;
        }

        .customer-name {
          font-weight: 600;
          margin-bottom: 5px;
        }

        .customer-phone {
          font-size: 0.9rem;
          color: rgba(255, 255, 255, 0.7);
        }

        .total-amount {
          font-weight: 600;
          color: var(--accent);
          font-size: 1.1rem;
        }

        /* Status Badges */
        .status-badge {
          display: inline-block;
          padding: 5px 12px;
          border-radius: 20px;
          font-size: 0.8rem;
          font-weight: 600;
          text-transform: uppercase;
          letter-spacing: 1px;
          text-align: center;
          min-width: 100px;
        }

        .status-new {
          background: rgba(255, 204, 0, 0.2);
          color: #ffcc00;
          border: 1px solid rgba(255, 204, 0, 0.5);
          box-shadow: 0 0 8px rgba(255, 204, 0, 0.3);
        }

        .status-processing {
          background: rgba(0, 153, 255, 0.2);
          color: #0099ff;
          border: 1px solid rgba(0, 153, 255, 0.5);
          box-shadow: 0 0 8px rgba(0, 153, 255, 0.3);
        }

        .status-ready {
          background: rgba(0, 255, 157, 0.2);
          color: #00ff9d;
          border: 1px solid rgba(0, 255, 157, 0.5);
          box-shadow: 0 0 8px rgba(0, 255, 157, 0.3);
        }

        .status-completed {
          background: rgba(0, 255, 0, 0.2);
          color: #00ff00;
          border: 1px solid rgba(0, 255, 0, 0.5);
          box-shadow: 0 0 8px rgba(0, 255, 0, 0.3);
        }

        .status-cancelled {
          background: rgba(255, 51, 51, 0.2);
          color: #ff3333;
          border: 1px solid rgba(255, 51, 51, 0.5);
          box-shadow: 0 0 8px rgba(255, 51, 51, 0.3);
        }

        /* Form Elements */
        .status-form {
          display: flex;
          align-items: center;
          gap: 8px;
        }

        .status-select {
          background: var(--darker);
          color: var(--light);
          border: 1px solid var(--gray);
          border-radius: 4px;
          padding: 8px 12px;
          outline: none;
          transition: var(--transition);
          min-width: 140px;
          font-size: 0.9rem;
          cursor: pointer;
        }

        .status-select:focus {
          border-color: var(--primary);
          box-shadow: var(--glow);
        }

        .update-btn {
          background: linear-gradient(to right, var(--primary), var(--accent));
          color: var(--darker);
          border: none;
          border-radius: 4px;
          padding: 8px 16px;
          cursor: pointer;
          font-weight: 600;
          text-transform: uppercase;
          letter-spacing: 1px;
          font-size: 0.8rem;
          transition: var(--transition);
          position: relative;
          overflow: hidden;
          white-space: nowrap;
        }

        .update-btn::before {
          content: '';
          position: absolute;
          top: 0;
          left: -100%;
          width: 100%;
          height: 100%;
          background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
          transition: var(--transition);
        }

        .update-btn:hover {
          transform: translateY(-2px);
          box-shadow: 0 5px 15px rgba(0, 240, 255, 0.4);
        }

        .update-btn:hover::before {
          left: 100%;
        }

        /* Animation for page load */
        @keyframes fadeIn {
          from { 
            opacity: 0; 
            transform: translateY(20px); 
          }
          to { 
            opacity: 1; 
            transform: translateY(0); 
          }
        }

        .container > * {
          animation: fadeIn 0.5s ease-out;
        }

        .dashboard-section {
          animation: fadeIn 0.7s ease-out;
        }

        .table tr {
          animation: fadeIn 0.3s ease-out;
        }

        /* Grid lines effect */
        body::before {
          content: '';
          position: fixed;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          background-image: 
            linear-gradient(rgba(0, 240, 255, 0.03) 1px, transparent 1px),
            linear-gradient(90deg, rgba(0, 240, 255, 0.03) 1px, transparent 1px);
          background-size: 20px 20px;
          pointer-events: none;
          z-index: -1;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
          .container {
            padding: 10px;
          }
          
          h1 {
            font-size: 2rem;
            text-align: center;
            display: block;
          }
          
          h2 {
            font-size: 1.4rem;
          }
          
          .admin-nav {
            flex-direction: column;
          }
          
          .admin-nav a {
            min-width: auto;
            padding: 12px 20px;
          }
          
          .status-form {
            flex-direction: column;
            align-items: stretch;
            gap: 5px;
          }
          
          .status-select, .update-btn {
            width: 100%;
            margin: 2px 0;
          }
          
          .table td, .table th {
            padding: 8px 10px;
            font-size: 0.9rem;
          }
          
          .status-badge {
            min-width: 80px;
            font-size: 0.7rem;
            padding: 4px 8px;
          }
        }
    </style>
</head>
<body>
    <div class='container'>
        <h1>Runners Admin</h1>
        <nav class='admin-nav'>
            <a href='admin_pages/products.php'>Products</a>
            <a href='admin_pages/customers.php'>Customers</a>
            <a href='admin_pages/orders.php'>Orders</a>
            <a href='admin_pages/completed.php'>Completed</a>
            <a href='admin_pages/inbox.php'>Inbox</a>
            <a href='settings.php'>Settings</a>
            <a href='admin_logout.php'>Logout</a>
        </nav>
        
        <section class='dashboard-section'>
            <h2>Recent Orders</h2>
            <div class='table-container'>
                <table class='table'>
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Order</th>
                            <th>Customer</th>
                            <th>Total</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($orders as $o): ?>
                        <tr>
                            <td><?php echo $o['id'] ?></td>
                            <td><?php echo htmlspecialchars($o['order_number']) ?></td>
                            <td>
                                <div class='customer-info'>
                                    <span class='customer-name'><?php echo htmlspecialchars($o['customer_name']) ?></span>
                                    <span class='customer-phone'><?php echo htmlspecialchars($o['phone']) ?></span>
                                </div>
                            </td>
                            <td class='total-amount'>R <?php echo number_format($o['total'],2) ?></td>
                            <td>
                                <span class='status-badge status-<?php echo htmlspecialchars($o['status']) ?>'>
                                    <?php echo htmlspecialchars($o['status']) ?>
                                </span>
                            </td>
                            <td>
                                <form method='post' class='status-form'>
                                    <input type='hidden' name='order_id' value='<?php echo $o['id'] ?>'>
                                    <select name='status' class='status-select'>
                                        <option value='new' <?php if($o['status']=='new') echo 'selected'?>>New</option>
                                        <option value='processing' <?php if($o['status']=='processing') echo 'selected'?>>Processing</option>
                                        <option value='ready' <?php if($o['status']=='ready') echo 'selected'?>>Ready</option>
                                        <option value='completed' <?php if($o['status']=='completed') echo 'selected'?>>Completed</option>
                                        <option value='cancelled' <?php if($o['status']=='cancelled') echo 'selected'?>>Cancelled</option>
                                    </select>
                                    <button type='submit' class='update-btn'>Update</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </section>
    </div>
</body>
</html>