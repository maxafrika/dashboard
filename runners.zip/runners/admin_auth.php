<?php
// admin_auth.php - robust: only start session if headers NOT already sent
// and avoid warnings if session already active.

if (PHP_SAPI !== 'cli') {
    // Only attempt in web context
    if (session_status() === PHP_SESSION_NONE) {
        // Only start session if headers not already sent
        if (!headers_sent()) {
            // suppress any warning with @ and let it start quietly
            @session_start();
        } else {
            // if headers already sent, do not attempt session_start to avoid warnings
            // leave $_SESSION as-is (may be unavailable)
            if (!isset($_SESSION)) {
                $_SESSION = [];
            }
        }
    }
}

function admin_is_logged_in() {
    return !empty($_SESSION['runners_admin']);
}

function admin_require_login() {
    if (!admin_is_logged_in()) {
        // Use header redirect when possible, fallback to JS link if headers already sent
        if (!headers_sent()) {
            header('Location: admin_login.php');
            exit;
        } else {
            echo '<script>window.location.href="admin_login.php";</script>';
            echo '<noscript><a href="admin_login.php">Login</a></noscript>';
            exit;
        }
    }
}

function admin_check_password($plain) {
    $f = __DIR__ . '/data/admin.json';
    if (file_exists($f)) {
        $j = json_decode(file_get_contents($f), true);
        if ($j && !empty($j['password_hash'])) {
            return password_verify($plain, $j['password_hash']);
        }
    }
    if (defined('ADMIN_PASSWORD_HASH') && ADMIN_PASSWORD_HASH) {
        return password_verify($plain, ADMIN_PASSWORD_HASH);
    }
    return false;
}
