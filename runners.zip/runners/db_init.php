<?php
require 'config.php';

try {
    $db = new PDO("sqlite:" . DB_FILE);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $schema = "
    CREATE TABLE IF NOT EXISTS products (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        description TEXT,
        price REAL,
        sku TEXT,
        image TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS customers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        phone TEXT,
        email TEXT,
        address TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS orders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        order_number TEXT UNIQUE,
        token TEXT UNIQUE,
        customer_id INTEGER,
        customer_name TEXT,
        phone TEXT,
        email TEXT,
        address TEXT,
        items TEXT,
        total REAL,
        status TEXT DEFAULT 'new',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS messages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        from_number TEXT,
        body TEXT,
        received_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        replied INTEGER DEFAULT 0
    );
    ";

    $db->exec($schema);

    echo "Database initialized successfully!";
} catch (Exception $e) {
    echo "Error: ".$e->getMessage();
}
?>
